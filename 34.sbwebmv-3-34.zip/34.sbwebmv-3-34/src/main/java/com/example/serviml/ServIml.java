package com.example.serviml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dbcls.R204;
import com.example.repo.Repo;
import com.example.repo.Servicess;
@Service
class ServIml  implements Servicess{
	@Autowired 
	private Repo rep;
	@Override
	     public  List<R204> getAllDet(){
			
				return rep.findAll();
	     }


}
