package com.inventory.demo;

import org.springframework.stereotype.Component;

@Component
public class InventoryFallback implements ProductClient {
    @Override
    public Integer getProductStock(Long productId) {
        return 0; // Return 0 if product service is down
    }
}
