 package com.example.controler;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.dbcls.R204;
import com.example.repo.Servicess;

@Controller
public class RoomControler {
	RoomControler()
	{
		System.out.print("this is controler class");
	}
	@Autowired 
	private Servicess serv;
	@GetMapping("/det")
	public ModelAndView getAllInfo()
	{
		ModelAndView mvr = new ModelAndView();
		List <R204> mem =serv.getAllDet();
		
		mvr.addObject("det",mem);
		mvr.setViewName("rooms");
		return mvr;
		
		
	}

}
