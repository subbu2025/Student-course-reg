package com.example.repo;

import java.util.List;

import com.example.dbcls.R204;

public interface Servicess {
	public  List<R204> getAllDet();

}
