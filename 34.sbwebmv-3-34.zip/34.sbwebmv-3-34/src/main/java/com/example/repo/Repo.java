package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.dbcls.R204;

public interface Repo extends JpaRepository<R204,Integer> {

}
